# JGR Broker - Sistema de Acompanhamento de Processos de Importação e Exportação

Este pacote contém todos os arquivos necessários para o deploy do sistema JGR Broker no Streamlit Cloud.

## Como fazer o deploy

1. Faça upload de todo o conteúdo deste pacote para um repositório no GitHub
2. Acesse https://share.streamlit.io e faça login com sua conta GitHub
3. Clique em 'New app', selecione seu repositório e configure:
   - Main file path: app.py
   - Python version: 3.11
4. Clique em 'Deploy!'

## Estrutura do projeto

- `app.py`: Arquivo principal da aplicação
- `data.py`: Gerenciamento de dados
- `components/`: Componentes da interface
- `assets/`: Recursos estáticos (CSS, imagens)
- `.streamlit/`: Configuração do Streamlit
- Outros arquivos de suporte para exportações HTML

## Login padrão

- Usuário: admin
- Senha: admin

## Observações

O sistema usa arquivos JSON para armazenamento de dados, o que é adequado para testes.
Para produção, recomenda-se migrar para um banco de dados.
