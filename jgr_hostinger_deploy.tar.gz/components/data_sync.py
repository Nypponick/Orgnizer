"""
Módulo para sincronização de dados entre usuários do sistema JGR Broker
Permite exportar e importar alterações
"""
import streamlit as st
import json
import os
import datetime
import base64
import copy
from io import BytesIO
from data import load_data, save_data
import pandas as pd

def display_data_sync():
    """
    Interface para sincronização de dados entre usuários
    """
    st.title("Sincronização de Dados")
    
    # Interface com guias para exportar e importar
    tabs = st.tabs(["Exportar Alterações", "Importar Alterações"])
    
    with tabs[0]:  # Exportar alterações
        display_export_tab()
    
    with tabs[1]:  # Importar alterações
        display_import_tab()

def display_export_tab():
    """
    Exibe a interface para exportar alterações
    """
    st.header("Exportar Alterações")
    st.write("Esta função permite gerar um arquivo com alterações para compartilhar com outros usuários.")
    
    # Explicar ao usuário como o processo funciona
    with st.expander("Como funciona?", expanded=False):
        st.write("""
        1. Selecione se deseja exportar todos os dados ou apenas de um cliente específico
        2. Clique no botão "Gerar arquivo de atualização"
        3. O sistema criará um arquivo de exportação com os dados selecionados
        4. Faça download do arquivo e envie para outros usuários
        5. Outros usuários poderão importar o arquivo na aba "Importar Alterações"
        """)
    
    # Carregar dados atuais
    data = load_data()
    
    # Utilizar a função especializada para obter todos os clientes
    import client_utils
    
    # Obter a lista de clientes usando a função centralizada
    client_list = client_utils.get_all_clients()
    
    # Adicionar opção de exportar todos os dados
    export_options = ["Todos os dados"] + client_list
    
    # Opção para selecionar exportação completa ou por cliente
    export_option = st.selectbox(
        "O que deseja exportar?", 
        options=export_options,
        index=0,
        help="Selecione 'Todos os dados' para exportar todos os processos, ou escolha um cliente específico"
    )
    
    # Botão para gerar o arquivo de atualização
    if st.button("Gerar arquivo de atualização", type="primary"):
        # Vamos preparar os dados conforme a opção selecionada
        if export_option == "Todos os dados":
            # Exportar todos os dados
            export_data_content = data
            file_prefix = "completo"
        else:
            # Exportar apenas dados do cliente selecionado
            client_name = export_option
            
            # Filtrar processos do cliente selecionado
            client_processes = []
            for process in data.get('processes', []):
                is_client_process = False
                
                # 1. Verificar eventos
                for event in process.get('events', []):
                    description = event.get('description', '')
                    if 'cliente' in description.lower() and client_name.lower() in description.lower():
                        is_client_process = True
                        break
                
                # 2. Verificar campo client explícito
                if 'client' in process and process['client'] and client_name.lower() in process['client'].lower():
                    is_client_process = True
                
                # 3. Verificar campo importer (comum em processos de importação)
                if 'importer' in process and process['importer'] and client_name.lower() in process['importer'].lower():
                    is_client_process = True
                
                # 4. Verificar campos de referência que podem conter o nome do cliente
                if 'ref' in process and process['ref'] and client_name.lower() in process['ref'].lower():
                    is_client_process = True
                
                # 5. Verificar observações que podem mencionar o cliente
                if 'observations' in process and process['observations'] and client_name.lower() in process['observations'].lower():
                    is_client_process = True
                
                # Se é um processo do cliente, adicionar à lista
                if is_client_process:
                    client_processes.append(process)
            
            # Criar uma cópia dos dados com apenas os processos do cliente
            export_data_content = copy.copy(data)
            export_data_content['processes'] = client_processes
            
            # Coletar status personalizados usados nos processos deste cliente
            status_used = set()
            for process in client_processes:
                if 'status' in process and process['status']:
                    status_used.add(process['status'])
            
            # Adicionar configurações necessárias para o cliente
            if 'config' not in export_data_content:
                export_data_content['config'] = {}
            
            # Adicionar status personalizados ao export se existirem
            if 'status_options' in data.get('config', {}) and status_used:
                # Filtrar apenas os status usados pelo cliente
                all_status_options = data.get('config', {}).get('status_options', {})
                client_status_options = {}
                
                for status_type, status_list in all_status_options.items():
                    client_status_list = [s for s in status_list if s in status_used]
                    if client_status_list:
                        client_status_options[status_type] = client_status_list
                
                # Adicionar à exportação
                export_data_content['config']['status_options'] = client_status_options
            
            file_prefix = client_name.lower().replace(' ', '_')
        
        # Adicionar timestamp e metadados à exportação
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        export_data = {
            "timestamp": timestamp,
            "user": st.session_state.get("username", "usuario_desconhecido"),
            "client": export_option if export_option != "Todos os dados" else None,
            "data": export_data_content
        }
        
        # Gerar nome do arquivo
        filename = f"atualizacao_jgr_{file_prefix}_{timestamp}.json"
        
        # Converter para JSON
        json_str = json.dumps(export_data, ensure_ascii=False, indent=2)
        
        # Criar link para download
        b64 = base64.b64encode(json_str.encode("utf-8")).decode()
        href = f'<a href="data:application/json;base64,{b64}" download="{filename}">📥 Clique aqui para baixar o arquivo de atualização</a>'
        
        # Exibir link de download
        st.success("Arquivo de atualização gerado com sucesso!")
        st.markdown(href, unsafe_allow_html=True)
        
        # Salvar localmente para referência
        export_dir = "updates_export"
        if not os.path.exists(export_dir):
            os.makedirs(export_dir)
        
        with open(os.path.join(export_dir, filename), "w", encoding="utf-8") as f:
            f.write(json_str)
        
        st.info(f"Uma cópia do arquivo também foi salva em {export_dir}/{filename}")

def merge_data(current_data, imported_data):
    """
    Mescla dados de forma inteligente, preservando dados existentes e adicionando/atualizando 
    apenas as informações novas ou modificadas.
    
    Args:
        current_data: Dados atuais do sistema
        imported_data: Dados importados do arquivo
        
    Returns:
        dict: Dados mesclados
    """
    # Adicionar logs para debug
    print(f"DEBUG - Mesclagem iniciada")
    print(f"DEBUG - Dados atuais: {len(current_data.get('processes', []))} processos")
    print(f"DEBUG - Dados importados: {len(imported_data.get('processes', []))} processos")
    
    # Criar uma cópia profunda dos dados atuais para não modificá-los diretamente
    merged_data = copy.copy(current_data)
    
    # Mesclar processos
    if 'processes' in imported_data:
        # Criar um dicionário de processos atuais para facilitar a busca
        current_processes = {p.get('id'): p for p in merged_data.get('processes', [])}
        
        # Lista para armazenar os processos após a mesclagem
        merged_processes = []
        
        # Para cada processo no arquivo importado
        for imported_process in imported_data.get('processes', []):
            process_id = imported_process.get('id')
            print(f"DEBUG - Analisando processo importado ID: {process_id}")
            
            if process_id in current_processes:
                # Se o processo já existe, verificar se pertence ao mesmo cliente
                current_process = current_processes[process_id]
                print(f"DEBUG - Processo ID {process_id} já existe no sistema, verificando cliente")
                
                # Extrair cliente dos eventos
                def extract_client_from_events(events):
                    for event in events:
                        desc = event.get('description', '')
                        if 'atribuído ao cliente' in desc:
                            # Extrair nome do cliente (após "atribuído ao cliente ")
                            try:
                                return desc.split('atribuído ao cliente ')[1]
                            except:
                                return None
                    return None
                
                current_client = extract_client_from_events(current_process.get('events', []))
                imported_client = extract_client_from_events(imported_process.get('events', []))
                
                print(f"DEBUG - Cliente atual: {current_client}, Cliente importado: {imported_client}")
                
                # Verificar também se a referência é diferente
                current_ref = current_process.get('ref', '')
                imported_ref = imported_process.get('ref', '')
                print(f"DEBUG - Referência atual: {current_ref}, Referência importada: {imported_ref}")
                
                # Se tiverem clientes diferentes OU referências diferentes, tratar como processos distintos
                if (current_client and imported_client and current_client != imported_client) or (current_ref and imported_ref and current_ref != imported_ref):
                    print(f"DEBUG - Mesmo ID, mas clientes ou referências diferentes.")
                    print(f"DEBUG - Tratando como processo distinto e preservando ambos")
                    
                    # Modificar ID do processo importado para evitar conflito
                    # Usar a referência ou o cliente para criar um sufixo único
                    suffix = ""
                    if imported_ref and imported_ref.strip():
                        # Usar as primeiras 3 letras da referência
                        ref_clean = str(imported_ref).replace(' ', '').replace('-', '').replace('/', '')
                        suffix = ref_clean[:3].upper() if ref_clean else "REF"
                    elif imported_client and imported_client.strip():
                        # Usar as primeiras 3 letras do cliente se não tiver referência
                        client_clean = str(imported_client).replace(' ', '')
                        suffix = client_clean[:3].upper() if client_clean else "CLI"
                    else:
                        # Se não tiver nem cliente nem referência, usar timestamp atual
                        suffix = datetime.datetime.now().strftime("%H%M%S")
                        
                    modified_id = f"{process_id}_{suffix}"
                    imported_process['id'] = modified_id
                    
                    # Adicionar evento explicando a modificação
                    if 'events' not in imported_process:
                        imported_process['events'] = []
                        
                    import uuid
                    imported_process['events'].append({
                        'id': str(uuid.uuid4()),
                        'date': datetime.datetime.now().strftime("%d/%m/%Y"),
                        'description': f"ID modificado durante sincronização (original: {process_id}) para evitar conflito com outro cliente",
                        'user': 'Sistema'
                    })
                    
                    print(f"DEBUG - Adicionando como novo processo com ID: {modified_id}")
                    merged_processes.append(imported_process)
                    merged_processes.append(current_process)  # Mantemos também o processo atual
                else:
                    # Mesmo cliente ou sem identificação de cliente - usar lógica de comparação por data
                    print(f"DEBUG - Mesmo cliente ou cliente não identificado, comparando datas")
                    
                    # Obter a data da última atualização dos processos
                    current_update = current_process.get('last_update', '')
                    imported_update = imported_process.get('last_update', '')
                    
                    try:
                        # Converter para objetos datetime para comparação
                        if current_update:
                            current_date = datetime.datetime.strptime(current_update, "%d/%m/%Y")
                        else:
                            current_date = datetime.datetime.min
                            
                        if imported_update:
                            imported_date = datetime.datetime.strptime(imported_update, "%d/%m/%Y")
                        else:
                            imported_date = datetime.datetime.min
                        
                        # Usar o processo mais recente
                        if imported_date >= current_date:
                            print(f"DEBUG - Utilizando processo importado mais recente ({imported_update} >= {current_update})")
                            merged_processes.append(imported_process)
                        else:
                            print(f"DEBUG - Mantendo processo atual mais recente ({current_update} > {imported_update})")
                            merged_processes.append(current_process)
                            
                    except (ValueError, TypeError) as e:
                        # Se houver erro na conversão de datas, manter o processo atual
                        print(f"DEBUG - Erro ao converter datas: {e}. Mantendo processo atual.")
                        merged_processes.append(current_process)
            else:
                # Se o processo não existe, adicionar o importado
                print(f"DEBUG - Adicionando novo processo ID: {process_id}")
                merged_processes.append(imported_process)
        
        # Adicionar processos que existem atualmente mas não estão no arquivo importado
        for process_id, process in current_processes.items():
            # Verificar se o processo já foi adicionado à lista mesclada
            if not any(p.get('id') == process_id for p in merged_processes):
                print(f"DEBUG - Mantendo processo atual não presente no arquivo importado: {process_id}")
                merged_processes.append(process)
        
        # Atualizar a lista de processos nos dados mesclados
        merged_data['processes'] = merged_processes
        print(f"DEBUG - Total de processos após mesclagem: {len(merged_processes)}")
    
    # Mesclar configurações se existirem
    if 'config' in imported_data:
        # Se não existir config nos dados atuais, criar
        if 'config' not in merged_data:
            merged_data['config'] = {}
        
        # Mesclar as configurações
        for key, value in imported_data['config'].items():
            merged_data['config'][key] = value
    
    # Mesclar usuários se existirem
    if 'users' in imported_data:
        # Se não existir users nos dados atuais, criar
        if 'users' not in merged_data:
            merged_data['users'] = []
        
        # Criar um dicionário de usuários atuais para facilitar a busca
        current_users = {u.get('username'): u for u in merged_data.get('users', [])}
        
        # Para cada usuário no arquivo importado
        for imported_user in imported_data.get('users', []):
            username = imported_user.get('username')
            
            if username in current_users:
                # Se o usuário já existe, manter o atual (não sobrescrever senhas)
                pass
            else:
                # Se o usuário não existe, adicionar
                merged_data['users'].append(imported_user)
    
    # Mesclar links compartilhados se existirem
    if 'shared_links' in imported_data:
        # Se não existir shared_links nos dados atuais, criar
        if 'shared_links' not in merged_data:
            merged_data['shared_links'] = {}
        
        # Mesclar os links
        for token, link_data in imported_data['shared_links'].items():
            # Apenas adicionar se o token não existir ou se o existente estiver expirado
            if token not in merged_data['shared_links']:
                merged_data['shared_links'][token] = link_data
    
    return merged_data

def display_import_tab():
    """
    Exibe a interface para importar alterações
    """
    st.header("Importar Alterações")
    st.write("Esta função permite importar alterações feitas por outros usuários do sistema.")
    
    # Explicar ao usuário como o processo funciona
    with st.expander("Como funciona?", expanded=False):
        st.write("""
        1. Carregue o arquivo de atualização recebido 
        2. O sistema verificará o conteúdo do arquivo
        3. Você poderá revisar as alterações antes de aplicá-las
        4. Após a confirmação, os dados serão atualizados
        """)
    
    # Upload do arquivo
    uploaded_file = st.file_uploader("Carregue o arquivo de atualização", type=["json"])
    
    if uploaded_file is not None:
        try:
            # Carregar dados do arquivo
            content = json.loads(uploaded_file.read().decode())
            
            # Verificar o formato do arquivo e extrair os dados corretamente
            if "timestamp" in content and "data" in content and isinstance(content["data"], dict):
                # Formato de exportação estruturado
                st.success("Arquivo carregado com sucesso!")
                st.write(f"**Data da atualização:** {content['timestamp']}")
                st.write(f"**Usuário que gerou:** {content.get('user', 'Não informado')}")
                
                # Extrair dados da estrutura completa
                imported_data = content["data"]
                st.info("Formato de sincronização detectado. Usando dados da chave 'data'.")
            else:
                # Assumimos que o arquivo é apenas os dados diretamente
                st.success("Arquivo carregado com sucesso!")
                st.write("**Formato:** Arquivo de dados direto (sem metadados)")
                
                # O conteúdo inteiro é considerado os dados
                imported_data = content
                st.info("Formato de backup completo detectado.")
            
            # Tabela com resumo de processos
            process_count = len(imported_data.get("processes", []))
            st.write(f"**Quantidade de processos:** {process_count}")
            
            if process_count > 0:
                # Criar DataFrame para visualização
                processes_df = pd.DataFrame(imported_data.get("processes", []))
                if not processes_df.empty:
                    summary_cols = ["id", "tipo", "status", "ref", "origin", "product"]
                    display_cols = [col for col in summary_cols if col in processes_df.columns]
                    
                    # Limitar o número de processos exibidos
                    if len(processes_df) > 10:
                        st.write("Mostrando os 10 primeiros processos:")
                        st.dataframe(processes_df[display_cols].head(10))
                    else:
                        st.dataframe(processes_df[display_cols])
            
            # Avisos importantes
            st.warning("⚠️ Atenção: Esta operação substituirá seus dados atuais pelos dados do arquivo. Recomenda-se fazer um backup antes de prosseguir.")
            
            # Opção para fazer backup automático antes de importar
            create_backup = st.checkbox("Criar backup dos dados atuais antes de importar", value=True)
            
            # Confirmação
            col1, col2 = st.columns([1, 3])
            with col1:
                confirm = st.button("Confirmar Importação", type="primary")
            
            if confirm:
                # Carregar dados atuais
                current_data = load_data()
                
                # Fazer backup se solicitado
                if create_backup:
                    backup_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    backup_filename = f"backup_antes_import_{backup_timestamp}.json"
                    
                    backup_dir = "backups"
                    if not os.path.exists(backup_dir):
                        os.makedirs(backup_dir)
                    
                    with open(os.path.join(backup_dir, backup_filename), "w", encoding="utf-8") as f:
                        json.dump(current_data, f, ensure_ascii=False, indent=2)
                    
                    st.info(f"Backup criado em {backup_dir}/{backup_filename}")
                
                # Método SIMPLIFICADO de importação - abordagem direta com suporte para clientes
                
                # Verificar se é uma importação específica de cliente
                client_name = None
                if "client" in content and content["client"] and content["client"] != "Todos os dados":
                    client_name = content["client"]
                    st.info(f"**Arquivo de sincronização do cliente:** {client_name}")
                    
                    # Verificar se o cliente já existe no sistema local
                    import client_utils
                    local_clients = client_utils.get_all_clients()
                    
                    if client_name not in local_clients:
                        st.warning(f"**Cliente '{client_name}' não encontrado no sistema local. Será criado automaticamente durante a importação.**")
                
                # Logs iniciais
                st.write(f"**Dados atuais:** {len(current_data.get('processes', []))} processos")
                st.write(f"**Dados no arquivo:** {len(imported_data.get('processes', []))} processos")
                
                # Abordagem direta para garantir que os dados sejam corretamente mesclados
                # Vamos simplesmente adicionar os processos que não existem e atualizar os existentes
                
                # 1. Criar uma cópia dos dados atuais
                merged_data = copy.copy(current_data)
                # Copiar a lista de processos explicitamente
                if 'processes' in current_data:
                    merged_data['processes'] = current_data['processes'].copy()
                
                # 2. Garantir que a estrutura básica existe
                if 'processes' not in merged_data:
                    merged_data['processes'] = []
                
                # 3. Criar um dicionário de processos atuais por ID para busca rápida
                current_processes_by_id = {p['id']: p for p in merged_data['processes']}
                
                # 4. Verificar se precisamos mesclar configurações (status personalizados)
                if 'config' in imported_data and 'status_options' in imported_data.get('config', {}):
                    # Verificar se temos configurações atuais
                    if 'config' not in merged_data:
                        merged_data['config'] = {}
                    
                    if 'status_options' not in merged_data['config']:
                        merged_data['config']['status_options'] = {}
                    
                    # Mesclar as opções de status
                    status_added = []
                    for status_type, status_list in imported_data['config']['status_options'].items():
                        # Garantir que o tipo de status existe
                        if status_type not in merged_data['config']['status_options']:
                            merged_data['config']['status_options'][status_type] = []
                        
                        # Adicionar status que não existem ainda
                        for status in status_list:
                            if status not in merged_data['config']['status_options'][status_type]:
                                merged_data['config']['status_options'][status_type].append(status)
                                status_added.append(status)
                    
                    if status_added:
                        st.success(f"**Status adicionados:** {', '.join(status_added)}")
                
                # 5. Processar cada processo do arquivo importado
                imported_count = 0
                updated_count = 0
                skipped_count = 0
                
                for imported_process in imported_data.get('processes', []):
                    process_id = imported_process.get('id')
                    
                    if not process_id:
                        skipped_count += 1
                        continue
                    
                    # Se é uma importação de cliente, verificar se o cliente já está atribuído
                    if client_name and 'events' in imported_process:
                        client_already_assigned = False
                        for event in imported_process.get('events', []):
                            description = event.get('description', '')
                            if 'atribuído ao cliente' in description:
                                client_already_assigned = True
                                break
                        
                        # Se o cliente não estiver atribuído, adicionar evento de atribuição
                        if not client_already_assigned:
                            if 'events' not in imported_process:
                                imported_process['events'] = []
                            
                            # Adicionar evento de atribuição ao cliente
                            import uuid
                            imported_process['events'].append({
                                'id': str(uuid.uuid4()),
                                'date': datetime.datetime.now().strftime("%d/%m/%Y"),
                                'description': f"Processo atribuído ao cliente {client_name}",
                                'user': 'Sistema (Importação)'
                            })
                    
                    # Verifica se o processo já existe
                    if process_id in current_processes_by_id:
                        # Buscar cliente do processo atual e do importado
                        current_client = None
                        imported_client = None
                        
                        for event in current_processes_by_id[process_id].get('events', []):
                            description = event.get('description', '')
                            if 'atribuído ao cliente' in description:
                                current_client = description.split('atribuído ao cliente')[1].strip()
                                break
                        
                        for event in imported_process.get('events', []):
                            description = event.get('description', '')
                            if 'atribuído ao cliente' in description:
                                imported_client = description.split('atribuído ao cliente')[1].strip()
                                break
                        
                        # Se o cliente do arquivo for diferente do atual, criar um novo processo
                        if current_client and imported_client and current_client != imported_client:
                            # Gerar um novo ID para o processo importado
                            client_suffix = imported_client.replace(' ', '')[:3].upper()
                            new_id = f"{process_id}_{client_suffix}"
                            
                            # Adicionar evento explicando a modificação
                            import uuid
                            imported_process['id'] = new_id
                            
                            if 'events' not in imported_process:
                                imported_process['events'] = []
                            
                            imported_process['events'].append({
                                'id': str(uuid.uuid4()),
                                'date': datetime.datetime.now().strftime("%d/%m/%Y"),
                                'description': f"ID modificado na importação para evitar conflito entre clientes (original: {process_id})",
                                'user': 'Sistema (Importação)'
                            })
                            
                            # Adicionar como novo processo
                            merged_data['processes'].append(imported_process)
                            imported_count += 1
                        else:
                            # Verificar referência para decidir se atualiza ou cria novo
                            current_ref = current_processes_by_id[process_id].get('ref', '')
                            imported_ref = imported_process.get('ref', '')
                            
                            # Se as referências forem diferentes, tratar como processos distintos
                            if current_ref and imported_ref and current_ref != imported_ref:
                                # Gerar um novo ID para o processo importado
                                suffix = "IMP"
                                if imported_ref:
                                    suffix = imported_ref.replace(' ', '')[:3].upper()
                                new_id = f"{process_id}_{suffix}"
                                
                                # Adicionar evento explicando a modificação
                                import uuid
                                imported_process['id'] = new_id
                                
                                if 'events' not in imported_process:
                                    imported_process['events'] = []
                                
                                imported_process['events'].append({
                                    'id': str(uuid.uuid4()),
                                    'date': datetime.datetime.now().strftime("%d/%m/%Y"),
                                    'description': f"ID modificado na importação (original: {process_id})",
                                    'user': 'Sistema (Importação)'
                                })
                                
                                # Adicionar como novo processo
                                merged_data['processes'].append(imported_process)
                                imported_count += 1
                            else:
                                # Atualizar o processo existente
                                # Encontrar e substituir na lista
                                for i, proc in enumerate(merged_data['processes']):
                                    if proc['id'] == process_id:
                                        merged_data['processes'][i] = imported_process
                                        break
                                updated_count += 1
                    else:
                        # Adicionar como novo processo
                        merged_data['processes'].append(imported_process)
                        imported_count += 1
                
                # 6. Atualizar o next_id se necessário
                if 'next_id' in imported_data:
                    try:
                        current_next_id = int(current_data.get('next_id', '0'))
                        imported_next_id = int(imported_data.get('next_id', '0'))
                        
                        if imported_next_id > current_next_id:
                            merged_data['next_id'] = str(imported_next_id)
                            st.info(f"Próximo ID atualizado para: {imported_next_id}")
                    except (ValueError, TypeError):
                        pass
                
                # Resumo das mudanças
                st.success(f"""
                **Resumo da importação:**
                - {imported_count} novos processos adicionados
                - {updated_count} processos atuais atualizados 
                - {skipped_count} processos ignorados (sem ID)
                - Total final: {len(merged_data['processes'])} processos
                """)
                
                # Mostrar alguns IDs
                process_ids = [p.get('id') for p in merged_data.get('processes', [])[:10]]
                st.write("**Alguns IDs após mesclagem:** " + ", ".join(process_ids) + ("..." if len(merged_data.get('processes', [])) > 10 else ""))
                
                # Salvar os dados mesclados
                save_data(merged_data)
                
                st.success("Dados importados com sucesso! A aplicação será reiniciada em instantes.")
                st.balloons()
                
                # Reiniciar a aplicação
                st.rerun()
                
        except Exception as e:
            st.error(f"Erro ao processar o arquivo: {str(e)}")

if __name__ == "__main__":
    display_data_sync()