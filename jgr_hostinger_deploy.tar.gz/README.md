# Instrucões para Deploy do JGR Broker na Hostinger

Este pacote contém todos os arquivos necessários para fazer o deploy do sistema JGR Broker na Hostinger utilizando Docker.

## Arquivos incluídos

- **Dockerfile**: Configuração para construir a imagem Docker
- **docker-compose.yml**: Configuração para executar o container
- **app.py**: Aplicação principal Streamlit
- **required_packages.txt**: Lista de pacotes Python necessários
- **data.json**: Banco de dados do sistema (será montado como volume)
- **users.json**: Dados de usuários (será montado como volume)
- **status_config.json**: Configurações de status personalizados
- **components/**: Diretório com os componentes da aplicação
- **.streamlit/**: Diretório com configurações do Streamlit

## Passos para Deploy

1. Faça upload de todos os arquivos para o servidor da Hostinger via FileZilla
2. Conecte-se ao servidor via SSH
3. Navegue até a pasta onde os arquivos foram carregados
4. Execute o comando:
   ```
   docker-compose up -d
   ```
5. A aplicação estará disponível na porta 8501 (ou conforme configurado)

## Importante

- Certifique-se que Docker e Docker Compose estão instalados no servidor da Hostinger
- Configure corretamente o proxy reverso no painel da Hostinger para apontar para a porta do contêiner
- Sempre faça backup dos arquivos data.json e users.json regularmente

## Manutenção

Para atualizar a aplicação:
1. Faça upload dos novos arquivos
2. Execute:
   ```
   docker-compose down
   docker-compose up -d --build
   ```

Para visualizar logs:
```
docker-compose logs -f
```