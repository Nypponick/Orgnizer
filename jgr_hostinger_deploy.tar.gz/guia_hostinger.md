# Guia de Deploy na Hostinger com Docker

Este guia irá ajudá-lo a fazer o deploy do sistema JGR Broker na Hostinger utilizando Docker.

## Pré-requisitos

1. Uma conta na Hostinger com acesso SSH ativado
2. FileZilla ou outro cliente FTP para upload de arquivos
3. Docker e Docker Compose instalados no servidor da Hostinger

## Passo a Passo

### 1. Preparação dos Arquivos

Os arquivos já estão organizados na pasta `jgr_hostinger_deploy`. Esta pasta contém:

- **Dockerfile**: Para construir a imagem Docker
- **docker-compose.yml**: Para gerenciar o container
- **Todos os arquivos do aplicativo**: código-fonte, dados, configurações, etc.

### 2. Upload via FileZilla

1. Abra o FileZilla e conecte-se ao seu servidor da Hostinger
2. No painel local, navegue até a pasta `jgr_hostinger_deploy`
3. Crie uma pasta no servidor (por exemplo, `jgr-broker`)
4. Faça upload de todos os arquivos para essa pasta

### 3. Configuração no Servidor

1. Conecte-se ao servidor via SSH:
   ```
   ssh seu-usuario@seu-servidor.hostinger.com
   ```

2. Navegue até a pasta onde você fez upload dos arquivos:
   ```
   cd jgr-broker
   ```

3. Construa e inicie o container:
   ```
   docker-compose up -d
   ```

4. Verifique se o container está rodando:
   ```
   docker-compose ps
   ```

### 4. Configuração do Proxy Reverso

Para acessar o aplicativo através de um domínio:

1. Acesse o painel da Hostinger
2. Configure um domínio ou subdomínio para apontar para o servidor
3. Configure o proxy reverso para encaminhar as requisições para a porta 5000

### 5. Acessando o Aplicativo

Após as configurações, você poderá acessar o aplicativo através do domínio configurado.

### 6. Manutenção

Para atualizar o aplicativo:

1. Faça upload dos novos arquivos via FileZilla
2. Conecte-se via SSH
3. Navegue até a pasta do aplicativo
4. Execute:
   ```
   docker-compose down
   docker-compose up -d --build
   ```

Para visualizar logs:
```
docker-compose logs -f
```

### 7. Backups

Para fazer backup dos dados:

1. Conecte-se via SSH
2. Navegue até a pasta do aplicativo
3. Copie os arquivos `data.json` e `users.json` para um local seguro:
   ```
   cp data.json data.json.backup
   cp users.json users.json.backup
   ```

## Solução de Problemas

Se o aplicativo não iniciar, verifique os logs:
```
docker-compose logs
```

Se for um problema de porta, verifique se a porta 5000 está disponível:
```
netstat -tuln | grep 5000
```

Se for um problema de permissão, verifique se os arquivos têm as permissões corretas:
```
chmod -R 755 .
```